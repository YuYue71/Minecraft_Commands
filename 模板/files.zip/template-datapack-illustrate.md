# 資料包總覽 (Datapack Overview)

> **分類:** `資料包`　｜　**適用版本:** `JE 1.XX+`

---

## 目錄

- [說明](#overview)
- [資料結構](#structure)
- [pack.mcmeta](#pack-mcmeta)
  - [pack_format 版本對應](#pack-format)
- [命名空間資料夾索引](#namespace-folders)
- [注意事項](#notes)
- [外部連結](#references)

---

## 說明 {#overview}

> 每次資料包有更新必須使用 `/reload` 指令來重新加載資料包

---

## 資料結構 {#structure}

```
datapack/
└── packname/
    ├── pack.mcmeta
    ├── pack.png
    └── data/
        ├── <namespace>/
        │   └── .../
        └── minecraft/
```

---

## pack.mcmeta {#pack-mcmeta}

```json
{
    "pack": {
        "pack_format": <版本編號>,
        "description": "此為資料包說明"
    }
}
```

### `pack_format` 版本對應 {#pack-format}

| 編號 | 版本 |
|------|------|
| `61` | 1.21.1+ |
| `57` | 1.21.0 |
| `48` | 1.20.5 – 1.20.6 |
| `26` | 1.20.3 – 1.20.4 |
| `18` | 1.20.2 |
| `15` | 1.20 – 1.20.1 |
| `12` | 1.19.3 – 1.19.4 |
| `10` | 1.19 – 1.19.2 |
| `8` | 1.18 – 1.18.2 |
| `7` | 1.17 – 1.17.1 |
| `6` | 1.16.2 – 1.16.5 |
| `5` | 1.15 – 1.16.1 |
| `4` | 1.14 – 1.14.4 |
| `1` | 1.13 – 1.13.2 |

---

## 命名空間資料夾索引 {#namespace-folders}

| 分類 | 資料夾名稱 | 主要功能用途 |
|------|-----------|------------|
| 生成地形 | [worldgen/](#) | 世界生成核心，包含結構、生物群系、特徵等 |
| 函式巨集 | [functions/](#) | 存放 `.mcfunction` 指令腳本，用於自動化執行指令 |
| 修改數據 | [loot_tables/](#) | 修改方塊挖掘、生物掉落物、釣魚或寶箱內容 |
| 成就進度 | [advancements/](#) | 定義成就系統，可用於觸發特殊事件或獎勵 |
| 自訂合成 | [recipes/](#) | 定義新的物品合成表（工作台、熔爐等）|
| 定義標籤 | [tags/](#) | 將多種方塊、物品或實體進行分組 |
| 生成結構 | [structures/](#) | 存放 `.nbt` 結構檔案 |
| 傷害類型 | [damage_type/](#) | 定義自定義的傷害來源類型 |
| 聊天訊息 | [chat_type/](#) | 自定義聊天室訊息的顯示格式 |
| 自訂維度 | [dimension/](#) | 定義新的維度 |
| 維度類型 | [dimension_type/](#) | 定義維度的環境屬性（亮度、天空顏色、高度限制）|
| 條件判斷 | [predicates/](#) | 自定義邏輯條件 |
| 物品修飾 | [item_modifiers/](#) | 在指令中修改物品屬性 |

---

## 注意事項 (Notes) {#notes}

- `namespace` 只允許小寫字母、數字、`_`、`-`、`.`，不可含大寫或空格
- `minecraft/` 命名空間會直接覆蓋原版內容，操作需謹慎
- 所有 JSON 路徑引用格式統一為 `namespace:path/to/file`，不含副檔名

---

## 外部連結 (References) {#references}

- [Minecraft Wiki - 資料包](#)
- [資料包管理指令](#)

---

*最後更新：YYYY-MM-DD*
